print('################################')
print('WELCOME TO THE DBS CONSOLE')
print('################################')

## Ask user to input the number of integers required
while 1==1:
    try:
        number_of_integers = int(input('Input the number of elements to be stored in the list: '))
        break
    except ValueError:
        print('Not a valid number please try again.')

print('Input ' + str(number_of_integers) + ' elements into the list.')

## Create a list to contain the integers
integers = []

## Ask user to input each integer individually up to the number of integers they specified above
while len(integers) < number_of_integers:
    try:
        integers.append(int(input('element - ' + str(len(integers))+' : ')))
    except ValueError:
        print('Not a valid number please try again.')

## Generate Outputs      
print('\nThe frequency of all elements of the list: ')
for integer in set(integers):
    print(str(integer) + ' occurs ' + str(integers.count(integer)) + ' times.')
