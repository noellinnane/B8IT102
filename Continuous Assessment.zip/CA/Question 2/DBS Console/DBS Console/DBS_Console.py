print('################################')
print('WELCOME TO THE DBS CONSOLE')
print('################################')
  
user_name = ''

while user_name.find('\\') == -1:
    print('Please enter your username: ')
    user_name = input()

user_name_2 = user_name.split('\\',2)

print('Domain: ' + user_name_2[0])
print('Username: ' + user_name_2[1])
