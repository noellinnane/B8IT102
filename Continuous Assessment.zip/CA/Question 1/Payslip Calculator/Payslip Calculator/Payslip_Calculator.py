### USER INPUTS ###

# Employee Name
employee_name_1 = input('Enter your name: ')

# Employee Number
employee_number_1 = input('Enter your Employee Number: ')

# Week Ending
week_ending_1 = input('Enter the week ending date: ')

# Number of Hours
while 1==1:
    try:
        hours_worked_1 = float(input('Enter the number of hours worked: '))
        break
    except ValueError:
        print('Not a valid number. Please try again.')

# Hourly Rate
while 1==1:
    try:
        hourly_rate_1 = float(input('Enter your hourly rate: '))
        break
    except ValueError:
        print('Not a valid number. Please try again.')

# Overtime Rate
while 1==1:
    try:
        overtime_rate_1 = float(input('Enter your overtime rate: '))
        break
    except ValueError:
        print('Not a valid number. Please try again.')

# Standard Tax Rate
while 1==1:
    try:
        standard_tax_rate_1 = float(input('Enter your standard tax rate: '))
        break
    except ValueError:
        print('Not a valid number. Please try again.')
        
# Overtime Tax Rate
while 1==1:
   try:
       overtime_tax_rate_1 = float(input('Enter your overtime tax rate: '))
       break
   except ValueError:
       print('Not a valid number. Please try again.')

### CALCULATIONS ###

# Number of hours at standard rate
if hours_worked_1 <= 37.5:
    standard_hours_1 = round(hours_worked_1,2)
else:
    standard_hours_1 = 37.50

# Number of hours at overtime rate
if hours_worked_1 > 37.5:
    overtime_hours_1 = round(hours_worked_1 - 37.5,2)
else:
   overtime_hours_1 = 0

# Overtime Rate
overtime_rate_2 = round(hourly_rate_1 * overtime_rate_1,2)   

# Standard Pay Gross
standard_pay_gross = round(standard_hours_1 * hourly_rate_1,2)

# Overtime Pay Gross
overtime_pay_gross = round(overtime_hours_1 * overtime_rate_2,2)

# Stanard Tax Amt
standard_tax_amt = round(standard_pay_gross * (standard_tax_rate_1/100),2)

# Overtime Tax Amt
overtime_tax_amt = round(overtime_pay_gross * (overtime_tax_rate_1/100),2)

# Total Pay
total_pay = round(standard_pay_gross + overtime_pay_gross,2)

# Deductions
deductions = round(standard_tax_amt + overtime_tax_amt,2)

# Net Pay
net_pay = round(total_pay - deductions,2)

print('                          P A Y S L I P                          ')
print('WEEK ENDING: ' + week_ending_1)
print('Employee Name: ' + employee_name_1)
print('Employee Number: ' + employee_number_1)
print('                      Earnings              Deductions')
print('                      Hours  Rate   Total')
print('Hours (normal)        ' + str(standard_hours_1) + '   ' + str(hourly_rate_1) + '   ' + str(standard_pay_gross) + '  Tax @ ' + str(standard_tax_rate_1) + '% ' + str(standard_tax_amt))
print('Hours (overtime)       ' + str(overtime_hours_1) + '   ' + str(overtime_rate_2) + '   ' + str(overtime_pay_gross) + '  Tax @ ' + str(overtime_tax_rate_1) + '% ' + str(overtime_tax_amt))
print('')
print('                       Total Pay: ' + str(total_pay))
print('                       Deductions: ' + str(deductions))
print('                       Net Pay: ' + str(net_pay))