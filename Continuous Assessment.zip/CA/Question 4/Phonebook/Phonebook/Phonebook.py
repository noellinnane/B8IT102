print('#######################################')
print('MYPY PHONEBOOK')
print('#######################################')


### FUNCTIONS

## MAIN MENU
# Function to call the main menu
# Offering the user multiple options, which in turn will call the appropriate function

def main_menu ():
    while 1==1:

        print('1: Add New Entry')
        print('2: Delete Entry')
        print('3: Update Entry')
        print('4: Lookup Number')
        print('5: Quit')

        user_option = input()

        if user_option == '1':
            add_new_entry()
        elif user_option == '2':
            delete_entry()
        elif user_option == '3':
            update_entry()
        elif user_option == '4':
            lookup_entry()
        elif user_option == '5':
            print('You have quit')
            break
        else:
            print('Not a valid option. Please try again.')

## ADD NEW ENTRY
# Function allowing the user to add a new entry to the phone book
# If the entry already exists an error will be presented to the user
            
def add_new_entry ():
    print('Add New Entry')

    while 1==1:
        new_number = str(input('Enter Number: '))
        new_name = str(input('Enter Name: '))
        if new_number not in phone_book:
            phone_book.update({new_number:new_name})
            print('Entry for ' + new_name + ', ' + new_number + ' successfully added.')
            break
        else:
            print('Number already exists.')
            break
            main_menu()

## DELETE AN ENTRY
# Function allowing the user to delete an entry from the phone book
# If the number does not exist an error will be presented to the user
            
def delete_entry ():
    print('Delete Entry')

    while 1==1:
        delete_number = str(input('Enter Number: '))
        if delete_number in phone_book:
            del phone_book[delete_number]
            print('Entry for ' + delete_number + ' successfully deleted.')
            break
        else:
            print('Number does not exist.')
            break
            main_menu()

## UPDATE AN ENTRY
# Function allowing the user to chnange an entry in the phone book

def update_entry ():
    print('Update Entry')

    while 1==1:
        try:
            old_number = input('Enter number to be updated: ')
            new_number = input('Enter new number: ')
            phone_book[new_number] = phone_book.pop(old_number)
            print(old_number + ' successfully updated to ' + new_number)
            break
        except KeyError:
            print('Number does not exist, please try again.')
            break
            main_menu()            

## LOOKUP ENTRY
# Function allowing the user to lookup an entry in the phone book
# If number does not exist user is given option to add entry
            
def lookup_entry ():
    print('Lookup Entry')
    
    while 1==1:
        try:
            lookup_number = input('Enter number: ')
            print(phone_book[lookup_number] + ', ' + lookup_number)
            break
        except KeyError:
            user_input = input('Number does not exist. Would you like to add entry? Y/N: ')
            if user_input.lower() == 'y':
                add_new_entry()
                break
            else:
                break
                main_menu ()

### Create a dictionary containing all entries

phone_book = {'1234567':'Alice'}


### Initate the program with the main menu

main_menu()